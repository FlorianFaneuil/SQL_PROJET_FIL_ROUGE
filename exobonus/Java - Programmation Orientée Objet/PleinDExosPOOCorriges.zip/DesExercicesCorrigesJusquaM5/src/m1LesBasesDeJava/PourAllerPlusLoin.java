package m1LesBasesDeJava;

import java.util.Random;
import java.util.Scanner;

public class PourAllerPlusLoin {
	private static String[] choix = {"Poule", "Renard", "Vipère"};
	
	public static void main(String[] args) {
		/*
		 * L'exercice ici consiste à créer un jeu de
		 * Poule - Renard - Vipère
		 * 
		 * Le programme tire au hasard la valeur "Poule",
		 * "Renard" ou "Vipère" sans l'indiquer au joueur
		 * 
		 * Le programme demande ensuite au joueur si il veut 
		 * jouer "Poule", "Renard" ou "Vipère"
		 * 
		 * Le programme indique ensuite au joueur si
		 * il a gagné, perdu ou bien égalité
		 * 
		 * Pour rappel : 
		 *  - La Poule bat la Vipère
		 *  - La Vipère bat le renard
		 *  - Le Renard bat la Poule
		 *  
		 *  (oui, ça fait beaucoup de "if" !)
		 *  
		 *  Pour aller encore plus loin : proposez au joueur un petit menu pour rejouer !
		 */
		int saisieUtilisateur = demanderSaisie();
		int choixOrdinateur = tirerOrdinateur();
		afficherResultat(saisieUtilisateur, choixOrdinateur);
	}
	
	private static int demanderSaisie() {
		System.out.println("Bienvenue sur le jeu de Poule-Renard-Vipère");
		System.out.println("Que voulez-vous faire ?");
		System.out.println("1 - " + choix[0]);
		System.out.println("2 - " + choix[1]);
		System.out.println("3 - " + choix[2]);
		Scanner scan = new Scanner(System.in);
		/*
		 * Je demande à mon utilisateur une saisie entre 1 et 3, mais en tant 
		 * que dev, je préfère manipuler de 0 à 2. Je retire donc 1 à la saisie
		 * de l'utilisateur
		 */
		int saisie = scan.nextInt() - 1;
		scan.close();
		System.out.println("Vous avez choisi de jouer " + choix[saisie]);
		return saisie;
	}
	
	private static int tirerOrdinateur() {
		Random rand = new Random();
		int tirageOrdi = rand.nextInt(3);
		System.out.println("L'ordinateur a joué " + choix[tirageOrdi]);
		return tirageOrdi;
	}
	
	private static void afficherResultat(int saisieUtilisateur, int choixOrdinateur) {
		// Je teste l'égalité
		if (saisieUtilisateur == choixOrdinateur) {
			System.out.println("Egalité !");
		}
		// Je teste les 3 conditions de défaite
		else if ((saisieUtilisateur == 0 && choixOrdinateur == 1)
				|| (saisieUtilisateur == 1 && choixOrdinateur == 2)
				|| (saisieUtilisateur == 2 && choixOrdinateur == 0)) {
			System.out.println("Haha t'as perdu");
		}
		// S'il n'y a ni égalité, ni défaite, alors il y a victoire
		else {
			System.out.println("Congratulations ! Tu as gagné !");
		}
	}
}
