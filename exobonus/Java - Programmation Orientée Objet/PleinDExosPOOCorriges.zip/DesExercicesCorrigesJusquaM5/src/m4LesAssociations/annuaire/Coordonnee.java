package m4LesAssociations.annuaire;

public class Coordonnee {
	private String fixe;
	private String portable;
	private Contact contact;
	
	public Coordonnee(String fixe, String portable) {
		this.fixe = fixe;
		this.portable = portable;
	}

	public String getFixe() {
		return fixe;
	}

	public void setFixe(String fixe) {
		this.fixe = fixe;
	}

	public String getPortable() {
		return portable;
	}

	public void setPortable(String portable) {
		this.portable = portable;
	}

	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

	@Override
	public String toString() {
		return "Coordonnee [fixe=" + fixe + ", portable=" + portable + "]";
	}
}
