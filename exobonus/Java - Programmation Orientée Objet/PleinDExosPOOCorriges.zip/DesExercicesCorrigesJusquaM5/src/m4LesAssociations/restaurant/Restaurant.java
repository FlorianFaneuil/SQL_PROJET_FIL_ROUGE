package m4LesAssociations.restaurant;

import java.util.Arrays;

public class Restaurant {
	private String nom;
	private Fournisseur fournisseurs[] = new Fournisseur[10];
	private int i = 0;
	
	public Restaurant(String nom) {
		this.nom = nom;
	}
	
	public void ajouter(Fournisseur fournisseur) {
		fournisseurs[i++] = fournisseur;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Fournisseur[] getFournisseurs() {
		return fournisseurs;
	}

	public void setFournisseurs(Fournisseur[] fournisseurs) {
		this.fournisseurs = fournisseurs;
	}

	@Override
	public String toString() {
		return "Restaurant [nom=" + nom + ", fournisseurs=" + Arrays.toString(fournisseurs) + "]";
	}
}
