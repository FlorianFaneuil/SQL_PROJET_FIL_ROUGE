package m4LesAssociations.restaurant;

public class Fournisseur {
	private String nom;
	private Restaurant[] restaurants = new Restaurant[10];
	private int i = 0;
	
	public Fournisseur(String nom) {
		this.nom = nom;
	}
	
	public void ajouterRestaurant(Restaurant restau) {
		restaurants[i++] = restau;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Restaurant[] getRestaurants() {
		return restaurants;
	}

	public void setRestaurants(Restaurant[] restaurants) {
		this.restaurants = restaurants;
	}

	@Override
	public String toString() {
		return nom;
	}
}
