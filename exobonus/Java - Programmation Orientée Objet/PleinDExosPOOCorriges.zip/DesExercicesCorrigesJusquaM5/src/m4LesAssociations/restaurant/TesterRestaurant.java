package m4LesAssociations.restaurant;

public class TesterRestaurant {
	public static void main(String[] args) {
		/*
		 * Créez les classes Restaurant et Fournisseur
		 * Un Restaurant est caractérisé par : 
		 *  - un nom
		 *  - une multitude de fournisseurs
		 *  
		 * Un Fournisseur est caractérisé par : 
		 *  - un nom
		 *  - une multitude de restaurants
		 * 
		 * Chaque classe dispose d'une méthode toString
		 * Chaque classe dispose de getters et de setters
		 * 
		 * Pour vous simplifier le traitement, on considère qu'un restaurant a maximum 10 fournisseurs,
		 * et qu'un fournisseur fourni un maximum de 10 restaurants.
		 * 
		 * Testez ensuite vos classes en créant plusieurs restaurants et plusieurs fournisseurs
		 */
		Fournisseur ferme = new Fournisseur("La ferme fruitière");
		Fournisseur picard = new Fournisseur("Picard");
		Fournisseur charal = new Fournisseur("Charal");
		Fournisseur boucher = new Fournisseur("Le boucher du coin");
		Fournisseur superu = new Fournisseur("Super U");
		Fournisseur gourmet = new Fournisseur("Grossiste gourmet");
		
		Restaurant pourri = new Restaurant("Le restau des gros nazes");
		Restaurant moyen = new Restaurant("La cabane a frites");
		Restaurant deluxe = new Restaurant("La Cigale");
		
		pourri.ajouter(superu);
		pourri.ajouter(picard);
		superu.ajouterRestaurant(pourri);
		picard.ajouterRestaurant(pourri);
		
		moyen.ajouter(superu);
		moyen.ajouter(boucher);
		moyen.ajouter(ferme);
		superu.ajouterRestaurant(moyen);
		boucher.ajouterRestaurant(moyen);
		ferme.ajouterRestaurant(moyen);
		
		deluxe.ajouter(gourmet);
		deluxe.ajouter(charal);
		deluxe.ajouter(ferme);
		gourmet.ajouterRestaurant(deluxe);
		charal.ajouterRestaurant(deluxe);
		ferme.ajouterRestaurant(deluxe);
		
		System.out.println("*** deluxe ***");
		System.out.println(deluxe);
		
		System.out.println("*** moyen ***");
		System.out.println(moyen);
		
		System.out.println("*** pourri ***");
		System.out.println(pourri);
	}
}
