package m4LesAssociations.philateliste;

public class TesterPhilateliste {
	public static void main(String[] args) {
		/*
		 * Créez deux classes, Timbre et Philateliste
		 * Un Timbre a un nom et une valeur
		 * 
		 * Un Philateliste a : 
		 *  - un nom
		 *  - un prenom
		 *  - une collection de Timbre
		 * 
		 * Chaque classe dispose d'une méthode toString
		 * Chaque classe dispose de getters et de setters
		 * Vous êtes libres de créer des méthodes supplémentaires si vous le jugez utile
		 * 
		 * Créez un philatéliste et affectez-lui des timbres, puis, affichez-le pour
		 * constater le bon fonctionnement de votre programme
		 */
		Timbre[] timbres = {
			new Timbre("Jeanne d'Arc", 100),
			new Timbre("Charlemagne", 40),
			new Timbre("Arc de Triomphe", 120),
			new Timbre("Etienne", 1)
		};
		
		Philateliste phil = new Philateliste("Ateliste", "Phil");
		phil.setTimbres(timbres);
		
		System.out.println(phil.toString());
	}
}
