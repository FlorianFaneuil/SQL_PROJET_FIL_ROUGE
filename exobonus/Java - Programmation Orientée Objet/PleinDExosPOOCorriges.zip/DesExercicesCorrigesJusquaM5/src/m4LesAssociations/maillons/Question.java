package m4LesAssociations.maillons;

public class Question {
	private String enonce;
	private boolean reponse;
	private Question suivante;
	
	public Question(String enonce, boolean reponse) {
		this.enonce = enonce;
		this.reponse = reponse;
	}

	public Question(String enonce, boolean reponse, Question suivante) {
		this.enonce = enonce;
		this.reponse = reponse;
		this.suivante = suivante;
	}

	public String getEnonce() {
		return enonce;
	}

	public void setEnonce(String enonce) {
		this.enonce = enonce;
	}

	public boolean isReponse() {
		return reponse;
	}

	public void setReponse(boolean reponse) {
		this.reponse = reponse;
	}

	public Question getSuivante() {
		return suivante;
	}

	public void setSuivante(Question suivante) {
		this.suivante = suivante;
	}
}
