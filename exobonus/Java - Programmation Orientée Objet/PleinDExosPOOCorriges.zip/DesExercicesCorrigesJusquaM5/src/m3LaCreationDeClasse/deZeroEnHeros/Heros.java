package m3LaCreationDeClasse.deZeroEnHeros;

public class Heros {
	private String nom;
	private int pv;
	private int atk;

	public Heros(String nom, int pv, int atk) {
		this.nom = nom;
		this.pv = pv;
		this.atk = atk;
	}
	
	public boolean estVivant() {
		return this.pv > 0;
	}
	
	public void attaquer(Heros autreHeros) {
		int pvAutreHeros = autreHeros.getPv();
		pvAutreHeros -= this.atk;
		autreHeros.setPv(pvAutreHeros);
		System.out.println(this.nom + " attaque " + autreHeros.getNom());
		System.out.println(this.toString());
		System.out.println(autreHeros.toString());
	}
	
	@Override
	public String toString() {
		return this.nom
				+ " (PV : "
				+ this.pv
				+ " - Atk : "
				+ this.atk
				+ ")";
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getPv() {
		return pv;
	}

	public void setPv(int pv) {
		this.pv = pv;
	}

	public int getAtk() {
		return atk;
	}

	public void setAtk(int atk) {
		this.atk = atk;
	}
}
