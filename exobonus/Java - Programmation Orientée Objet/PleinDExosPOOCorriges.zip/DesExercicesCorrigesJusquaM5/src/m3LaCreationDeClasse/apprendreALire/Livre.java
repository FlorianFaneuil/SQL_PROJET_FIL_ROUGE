package m3LaCreationDeClasse.apprendreALire;

public class Livre {
	private String nom;
	private int nbPages;
	private String[] pages;
	
	private int index = 0;
	
	public Livre(String nom, int nbPages) {
		this.nom = nom;
		this.nbPages = nbPages;
		this.pages = new String[nbPages];
	}
	
	public void ajouterPage(String nouvellePage) {
		pages[index] = nouvellePage;
		index++;
	}
	
	public String consulterPage(int numero) {
		return this.pages[numero];
	}
	
	@Override
	public String toString() {
		String resultat = this.nom;
		resultat += " (" + this.nbPages + " pages)\n";
		for (String page : this.pages) {
			resultat += page + "\n";
		}
		return resultat;
	}
}
