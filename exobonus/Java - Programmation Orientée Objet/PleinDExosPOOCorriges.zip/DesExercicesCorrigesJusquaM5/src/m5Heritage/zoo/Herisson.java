package m5Heritage.zoo;

public class Herisson extends Animal {
	private int nbAiguilles;
	
	public Herisson(String nom, int nbAiguilles) {
		super(nom);
		this.nbAiguilles = nbAiguilles;
	}
	
	public int getNbAiguilles() {
		return nbAiguilles;
	}
	
	public void setNbAiguilles(int nbAiguilles) {
		this.nbAiguilles = nbAiguilles;
	}
	
	@Override
	public String toString() {
		return this.nom + " le hérisson aux " + this.nbAiguilles + " aiguilles";
	}
}
