package m5Heritage.zoo;

public class Paresseux extends Animal {
	private boolean endormi;
	
	public Paresseux(String nom, boolean endormi) {
		super(nom);
		this.endormi = endormi;
	}
	
	public void setEndormi(boolean endormi) {
		this.endormi = endormi;
	}
	
	public boolean isEndormi() {
		return endormi;
	}
	
	@Override
	public String toString() {
		return this.nom + " le paresseux " + (this.endormi ? "endormi": "réveillé");
	}
}
