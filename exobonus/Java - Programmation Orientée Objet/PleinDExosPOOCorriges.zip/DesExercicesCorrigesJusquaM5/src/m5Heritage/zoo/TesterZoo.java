package m5Heritage.zoo;

public class TesterZoo {
	public static void main(String[] args) {
		/*
		 * Créez les classes Animal, Hérisson, Paresseux et Renard.
		 * Chaque Animal a un nom
		 * Un hérisson a un nombre d'épine
		 * Un paresseux a un état (endormi ou non)
		 * Un renard a une couleur
		 * 
		 * La classe Animal ne doit pas pouvoir être instanciée
		 * Chaque méthode dispose d'une méthode toString
		 * 
		 * Créez ensuite quelques animaux afin de tester vos classes
		 */
		Animal[] animaux = {
			new Herisson("Sonic", 10),
			new Paresseux("Flash", false),
			new Renard("Rouky", "roux"),
			new Paresseux("Sloth", true)
		};
		
		for (Animal current : animaux) {
			System.out.println(current);
		}
	}
}
