package m5Heritage.magasin;

import m5Heritage.magasin.Clavier.Disposition;

public class TesterMagasin {
	public static void main(String[] args) {
		/*
		 * Créez 4 classes : Magasin, Article, Ecran, Clavier
		 * Un Article dispose des attributs suivants : 
		 *  - un nom
		 *  - une quantite
		 *  - un prix
		 *  
		 * Un Ecran est un Article, et dispose en plus des attributs : 
		 *  - une taille en pouce
		 *  - une résolution (String)
		 *  
		 * Un Clavier est un Article, et dispose en plus de l'attribut : 
		 *  - une dispostion (azerty ou qwerty)
		 *  
		 * Un Magasin dispose des attributs suivants : 
		 *  - un nom
		 *  - une collection d'articles
		 *  
		 * Chaque classe dispose d'un toString, de getters et de setters
		 * La classe Magasin met également a disposition une méthode permettant d'ajouter un article à sa collection
		 * 
		 * Créez un magasin, plusieurs articles, et affichez votre magasin pour constater le bon fonctionnement
		 * de votre application
		 */
		Magasin boulanger = new Magasin("Boulanger");
		boulanger.ajouterArticle(new Ecran("Dell", 10, 120f, 27, "1920x1080"));
		boulanger.ajouterArticle(new Ecran("Sony", 20, 80f, 23, "1080x800"));
		boulanger.ajouterArticle(new Ecran("Samsung", 5, 1000f, 62, "4K"));
		
		boulanger.ajouterArticle(new Clavier("Predator", 10, 40f, Disposition.AZERTY));
		boulanger.ajouterArticle(new Clavier("Corsair", 5, 70f, Disposition.QWERTY));
		
		System.out.println(boulanger.toString());
	}
}
