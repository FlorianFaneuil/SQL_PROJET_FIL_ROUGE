package m5Heritage.magasin;

public class Ecran extends Article {
	private int taille;
	private String resolution;
	
	public Ecran(String nom, int quantite, float prix, int taille, String resolution) {
		super(nom, quantite, prix);
		this.taille = taille;
		this.resolution = resolution;
	}

	public int getTaille() {
		return taille;
	}

	public void setTaille(int taille) {
		this.taille = taille;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	@Override
	public String toString() {
		return "Ecran [taille=" + taille + ", resolution=" + resolution + ", nom=" + nom + ", quantite=" + quantite
				+ ", prix=" + prix + "]";
	}
}
