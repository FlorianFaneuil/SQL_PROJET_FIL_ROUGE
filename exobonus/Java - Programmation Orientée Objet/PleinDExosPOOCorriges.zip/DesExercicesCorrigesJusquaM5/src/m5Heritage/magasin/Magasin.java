package m5Heritage.magasin;

public class Magasin {
	private String nom;
	private Article[] articles;
	private int nbArticles;
	
	public Magasin(String nom) {
		this.nom = nom;
		articles = new Article[10];
		this.nbArticles = 0;
	}

	public void ajouterArticle(Article article) {
		articles[nbArticles++] = article;
	}
	
	@Override
	public String toString() {
		String resultat = "Magasin " + this.nom + "\n";
		for (Article current : articles) {
			if (current != null) {
				resultat += " * " + current.toString() + "\n";
			}
		}
		return resultat;
	}
}
