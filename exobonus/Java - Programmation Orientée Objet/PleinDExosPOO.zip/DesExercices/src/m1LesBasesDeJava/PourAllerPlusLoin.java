package m1LesBasesDeJava;

public class PourAllerPlusLoin {
	public static void main(String[] args) {
		/*
		 * L'exercice ici consiste à créer un jeu de
		 * Poule - Renard - Vipère
		 * 
		 * Le programme tire au hasard la valeur "Poule",
		 * "Renard" ou "Vipère" sans l'indiquer au joueur
		 * 
		 * Le programme demande ensuite au joueur si il veut 
		 * jouer "Poule", "Renard" ou "Vipère"
		 * 
		 * Le programme indique ensuite au joueur si
		 * il a gagné, perdu ou bien égalité
		 * 
		 * Pour rappel : 
		 *  - La Poule bat la Vipère
		 *  - La Vipère bat le renard
		 *  - Le Renard bat la Poule
		 *  
		 *  (oui, ça fait beaucoup de "if" !)
		 *  
		 *  Pour aller encore plus loin : proposez au joueur un petit menu pour rejouer !
		 */
		
	}
}
