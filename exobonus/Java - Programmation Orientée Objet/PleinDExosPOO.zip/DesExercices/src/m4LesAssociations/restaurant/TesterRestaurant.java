package m4LesAssociations.restaurant;

public class TesterRestaurant {
	public static void main(String[] args) {
		/*
		 * Créez les classes Restaurant et Fournisseur
		 * Un Restaurant est caractérisé par : 
		 *  - un nom
		 *  - une multitude de fournisseurs
		 *  
		 * Un Fournisseur est caractérisé par : 
		 *  - un nom
		 *  - une multitude de restaurants
		 * 
		 * Chaque classe dispose d'une méthode toString
		 * Chaque classe dispose de getters et de setters
		 * 
		 * Pour vous simplifier le traitement, on considère qu'un restaurant a maximum 10 fournisseurs,
		 * et qu'un fournisseur fourni un maximum de 10 restaurants.
		 * 
		 * Testez ensuite vos classes en créant plusieurs restaurants et plusieurs fournisseurs
		 */
	}
}
